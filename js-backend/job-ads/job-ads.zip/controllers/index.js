const homeController = require('./homeController');
const userController = require('./usersController');
const adsController = require('./adsController');

module.exports = {
    homeController,
    userController,
    adsController
}